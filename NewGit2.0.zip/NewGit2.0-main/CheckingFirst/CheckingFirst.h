#ifndef CHECKINGFIRST_H
#define CHECKINGFIRST_H

int task();

#endif