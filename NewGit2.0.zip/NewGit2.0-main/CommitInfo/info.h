#ifndef INFO_H
#define INFO_H

void gettingInfo();

#endif