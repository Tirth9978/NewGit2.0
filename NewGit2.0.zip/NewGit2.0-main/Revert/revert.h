#ifndef REVERT_H
#define REVERT_H

void revertById(char * id) ;
void revertByLastCommit();
void revertByFirstCommit();

#endif