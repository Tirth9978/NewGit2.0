#ifndef MAKECONFIG_H
#define MAKECONFIG_H

int findMainConfigFile();
void SecondAgrumentChecking();
void makeFile();
void addConfigUser(); 
void ReadingConfigData();

#endif