#ifndef INITIALIZATION_H
#define INITIALIZATION_H

void makingDotGitFolder();
void makingStagingIdInfoFile() ;
void makingStagingIdsFolder() ; 
void makingInitInfoFile();

#endif