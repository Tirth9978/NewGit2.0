#ifndef COMMIT_H
#define COMMIT_H

void appendMessage();
void gettingConfigUserInfo();

#endif